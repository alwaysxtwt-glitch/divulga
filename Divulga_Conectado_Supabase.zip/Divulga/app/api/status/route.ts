import {json,identity,error} from "../../../lib/server";
import {networks} from "../../../lib/contracts";

const SUPABASE_URL="https://qmgykhnpzxuzjywlnahg.supabase.co";
const SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInFtZ3lraG5wenh1emp5d2xuYWhnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4ODE2MjcsImV4cCI6MjEwNjQ1NzYyN30.JSSxUMGX6u3Wy2FRhySR5BjP9JYzFZA2SX4bnlgR-WA";

export async function GET(req:Request){
 if(!await identity(req))return error("Entre para continuar.",401);
 let ai=false;
 try{
  const response=await fetch(`${SUPABASE_URL}/functions/v1/divulga-ai`,{
   method:"POST",
   headers:{
    "Content-Type":"application/json",
    apikey:SUPABASE_ANON_KEY,
    Authorization:`Bearer ${SUPABASE_ANON_KEY}`,
   },
   signal:AbortSignal.timeout(8000),
   body:JSON.stringify({action:"status"}),
  });
  if(response.ok){
   const data:any=await response.json();
   ai=data?.connected===true;
  }
 }catch(e){console.error("ai-status",e);}
 return json({ai,uploads:false,networks:Object.fromEntries(networks.map(n=>[n,false]))});
}
