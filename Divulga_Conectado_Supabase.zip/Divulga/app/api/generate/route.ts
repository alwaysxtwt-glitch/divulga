import {campaignInput} from "../../../lib/contracts";
import {identity,json,error,body} from "../../../lib/server";

const SUPABASE_URL="https://qmgykhnpzxuzjywlnahg.supabase.co";
const SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtZ3lraG5wenh1emp5d2xuYWhnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4ODE2MjcsImV4cCI6MjEwNjQ1NzYyN30.JSSxUMGX6u3Wy2FRhySR5BjP9JYzFZA2SX4bnlgR-WA";

export async function POST(req:Request){
 if(!await identity(req))return error("Entre para continuar.",401);
 try{
  const p=campaignInput.safeParse(await body(req));
  if(!p.success)return error(p.error.issues[0].message);
  const f=p.data;

  const response=await fetch(`${SUPABASE_URL}/functions/v1/divulga-ai`,{
   method:"POST",
   headers:{
    "Content-Type":"application/json",
    apikey:SUPABASE_ANON_KEY,
    Authorization:`Bearer ${SUPABASE_ANON_KEY}`,
   },
   signal:AbortSignal.timeout(55000),
   body:JSON.stringify({
    title:f.title,
    brand:f.brand,
    audience:f.audience,
    goal:f.goal,
    tone:f.tone,
    brief:f.brief,
    networks:f.networks,
   }),
  });

  let data:any={};
  try{data=await response.json();}catch{}
  if(!response.ok){
   console.error("supabase-generation-http",response.status,data?.error||"");
   return error(data?.error||"A IA não respondeu. Tente novamente.",502);
  }

  if(!data?.variants||f.networks.some(n=>typeof data.variants[n]!=="string"||!data.variants[n].trim()||data.variants[n].length>5000))
   return error("O conteúdo retornado precisa ser gerado novamente.",502);
  if(f.networks.includes("TikTok")&&(typeof data.scripts?.TikTok!=="string"||!data.scripts.TikTok.trim()||data.scripts.TikTok.length>5000))
   return error("O roteiro do TikTok precisa ser gerado novamente.",502);

  return json({
   variants:Object.fromEntries(f.networks.map(n=>[n,data.variants[n]])),
   scripts:f.networks.includes("TikTok")?{TikTok:data.scripts.TikTok}:{},
  });
 }catch(e){
  console.error("generation",e);
  return error("Não foi possível gerar agora. Seu briefing foi mantido.",502);
 }
}
