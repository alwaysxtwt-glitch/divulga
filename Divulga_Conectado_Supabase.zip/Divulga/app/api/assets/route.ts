import {database,identity,json,error,runtimeEnv} from "../../../lib/server";
const allowed=["image/jpeg","image/png","image/webp","video/mp4"];
export async function POST(req:Request){const owner=await identity(req);if(!owner)return error("Entre para enviar arquivos.",401);if(!runtimeEnv.BUCKET)return error("Envio de arquivos indisponível.",503);try{
 if(Number(req.headers.get("content-length")||0)>21*1024*1024)return error("O arquivo deve ter até 20 MB.");
 const data=await req.formData(),file=data.get("file");if(!(file instanceof File)||!allowed.includes(file.type)||file.size>20*1024*1024||file.size===0)return error("Envie JPG, PNG, WebP ou MP4 de até 20 MB.");
 const id=crypto.randomUUID();await runtimeEnv.BUCKET.put(id,file.stream(),{httpMetadata:{contentType:file.type}});
 try{await database().prepare("INSERT INTO assets(id,owner,filename,mime,size,created_at) VALUES(?,?,?,?,?,?)").bind(id,owner,file.name.slice(0,200),file.type,file.size,new Date().toISOString()).run();}catch(e){await runtimeEnv.BUCKET.delete(id);throw e;}
 return json({id,filename:file.name,mime:file.type},201);
 }catch(e){console.error("asset-upload",e);return error("Não foi possível enviar o arquivo. Tente novamente.",503);}}
