import {database,identity,error,runtimeEnv} from "../../../../lib/server";
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){const owner=await identity(req);if(!owner)return error("Entre para acessar o arquivo.",401);try{
 const {id}=await params,row=await database().prepare("SELECT mime FROM assets WHERE id=? AND owner=?").bind(id,owner).first<{mime:string}>();if(!row)return error("Arquivo não encontrado.",404);
 const obj=await runtimeEnv.BUCKET?.get(id);if(!obj)return error("Arquivo não encontrado.",404);
 return new Response(obj.body,{headers:{"Content-Type":row.mime,"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff","Content-Security-Policy":"default-src 'none'"}});
 }catch(e){console.error("asset-read",e);return error("Arquivo temporariamente indisponível.",503);}}
