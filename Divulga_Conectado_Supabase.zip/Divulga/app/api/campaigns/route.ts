import {campaignInput} from "../../../lib/contracts";
import {database,identity,json,error,body} from "../../../lib/server";
export async function GET(req:Request){const owner=await identity(req);if(!owner)return error("Entre com sua conta para acessar as campanhas.",401);try{
 const db=database();const [list,history]=await Promise.all([db.prepare("SELECT * FROM campaigns WHERE owner=? ORDER BY updated_at DESC LIMIT 200").bind(owner).all<any>(),db.prepare("SELECT id,title,action,created_at AS createdAt FROM events WHERE owner=? ORDER BY created_at DESC LIMIT 100").bind(owner).all()]);
 return json({campaigns:list.results.map(row=>({...JSON.parse(row.payload),id:row.id,status:row.status,scheduledAt:row.scheduled_at,createdAt:row.created_at,updatedAt:row.updated_at,version:row.version})),events:history.results});
 }catch(e){console.error("campaign-list",e);return error("Não foi possível carregar suas campanhas. Tente novamente.",503);}}
export async function POST(req:Request){const owner=await identity(req);if(!owner)return error("Entre com sua conta para salvar.",401);try{
 const parsed=campaignInput.safeParse(await body(req));if(!parsed.success)return error(parsed.error.issues[0].message);const v=parsed.data,db=database();
 if(v.assetId&&!await db.prepare("SELECT id FROM assets WHERE id=? AND owner=?").bind(v.assetId,owner).first())return error("Arquivo inválido.");
 const id=crypto.randomUUID(),now=new Date().toISOString();
 await db.batch([db.prepare("INSERT INTO campaigns(id,owner,title,payload,status,scheduled_at,created_at,updated_at,version) VALUES(?,?,?,?,?,?,?,?,1)").bind(id,owner,v.title,JSON.stringify(v),v.status,v.scheduledAt,now,now),db.prepare("INSERT INTO events(id,owner,campaign_id,title,action,created_at) VALUES(?,?,?,?,?,?)").bind(crypto.randomUUID(),owner,id,v.title,v.status==="draft"?"Rascunho criado":v.status==="approved"?"Conteúdo aprovado":"Planejamento salvo; aguardando conexão",now)]);
 return json({...v,id,createdAt:now,updatedAt:now,version:1},201);
 }catch(e){console.error("campaign-save",e);return error("Não foi possível salvar. Seu texto foi mantido; tente novamente.",503);}}
