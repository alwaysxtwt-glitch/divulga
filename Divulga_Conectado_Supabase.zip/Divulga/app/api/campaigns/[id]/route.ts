import {campaignInput} from "../../../../lib/contracts";
import {database,identity,json,error,body} from "../../../../lib/server";
export async function PUT(req:Request,{params}:{params:Promise<{id:string}>}){const owner=await identity(req);if(!owner)return error("Entre com sua conta para salvar.",401);try{
 const {id}=await params,p=campaignInput.safeParse(await body(req));if(!p.success)return error(p.error.issues[0].message);const v=p.data,db=database();
 const row=await db.prepare("SELECT version,created_at FROM campaigns WHERE id=? AND owner=?").bind(id,owner).first<any>();if(!row)return error("Campanha não encontrada.",404);if(row.version!==v.version)return error("Esta campanha foi alterada. Reabra a versão atual antes de salvar.",409);
 if(v.assetId&&!await db.prepare("SELECT id FROM assets WHERE id=? AND owner=?").bind(v.assetId,owner).first())return error("Arquivo inválido.");
 const now=new Date().toISOString(),action=v.status==="draft"?"Rascunho atualizado":v.status==="approved"?"Conteúdo aprovado":"Planejamento salvo; aguardando conexão";
 const result=await db.batch([db.prepare("UPDATE campaigns SET title=?,payload=?,status=?,scheduled_at=?,updated_at=?,version=version+1 WHERE id=? AND owner=? AND version=?").bind(v.title,JSON.stringify(v),v.status,v.scheduledAt,now,id,owner,v.version),db.prepare("INSERT INTO events(id,owner,campaign_id,title,action,created_at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM campaigns WHERE id=? AND owner=? AND updated_at=? AND version=?)").bind(crypto.randomUUID(),owner,id,v.title,action,now,id,owner,now,v.version!+1)]);
 if(!result[0].meta.changes)return error("A campanha foi alterada. Reabra para continuar.",409);
 return json({...v,id,createdAt:row.created_at,updatedAt:now,version:row.version+1});
 }catch(e){console.error("campaign-update",e);return error("Não foi possível salvar. Seu texto foi mantido; tente novamente.",503);}}
