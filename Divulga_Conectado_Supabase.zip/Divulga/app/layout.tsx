import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Divulga · Central de campanhas",
  description: "Crie campanhas e organize publicações para Instagram, Facebook, LinkedIn e TikTok.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
