import { z } from "zod";
export const networks = ["Instagram", "Facebook", "LinkedIn", "TikTok"] as const;
export type Network = typeof networks[number];
export const campaignInput = z.object({
 title: z.string().trim().min(1).max(120), brand:z.string().trim().min(1).max(120),
 audience:z.string().trim().max(500), brief:z.string().trim().min(1).max(5000),
 goal:z.enum(["Atrair clientes","Divulgar uma oferta","Fortalecer a marca"]),tone:z.enum(["Próximo e amigável","Profissional","Direto e objetivo"]),
 networks:z.array(z.enum(networks)).min(1).max(networks.length).refine(v=>new Set(v).size===v.length),
 variants:z.record(z.string().max(5000)),scripts:z.record(z.string().max(5000)).default({}),status:z.enum(["draft","approved","awaiting_connection"]),
 scheduledAt:z.string().datetime().nullable(),assetId:z.string().uuid().nullable(),version:z.number().int().positive().optional()
}).superRefine((v,ctx)=>{
 if(v.status!=="draft"&&v.networks.some(n=>!v.variants[n]?.trim()))ctx.addIssue({code:"custom",message:"Escreva a versão de cada rede antes de aprovar."});
 if(v.status==="awaiting_connection"&&(!v.scheduledAt||Date.parse(v.scheduledAt)<=Date.now()))ctx.addIssue({code:"custom",message:"Escolha uma data e horário futuros."});
});
export type CampaignInput=z.infer<typeof campaignInput>;
export type Campaign=CampaignInput&{id:string;createdAt:string;updatedAt:string;version:number};
export type Event={id:string;title:string;action:string;createdAt:string};
export function initialForm():CampaignInput{return {title:"",brand:"",audience:"",brief:"",goal:"Atrair clientes",tone:"Próximo e amigável",networks:["Instagram","Facebook"],variants:{},scripts:{},status:"draft",scheduledAt:null,assetId:null};}
export function templateVariants(f:CampaignInput){
 const cta=f.goal==="Atrair clientes"?"Fale com a gente e saiba mais.":f.goal==="Divulgar uma oferta"?"Entre em contato para conferir os detalhes.":"Conheça nossa marca e acompanhe as novidades.";
 return Object.fromEntries(f.networks.map(n=>[n,n==="Instagram"?`${f.brand} ✨\n\n${f.brief}\n\n${cta}\n\n#Novidades`:n==="Facebook"?`${f.brand}: ${f.title}\n\n${f.brief}\n\n${cta}`:n==="TikTok"?`${f.title} ✨\n\n${f.brief}\n\n${cta}\n\n#${f.brand.replace(/[^\p{L}\p{N}]/gu,"")||"Novidades"}`:`${f.title}\n\nA ${f.brand} apresenta:\n\n${f.brief}\n\n${cta}`]));
}
export function templateScripts(f:CampaignInput){return f.networks.includes("TikTok")?{TikTok:`ROTEIRO SUGERIDO · 20–30 segundos\n\n0–3s · Gancho\nMostre a marca ou o produto e anuncie: “${f.title}”.\n\n3–20s · Conteúdo\nApresente os detalhes do briefing com imagens reais:\n${f.brief}\n\n20–30s · Convite\nConvide o público a saber mais sobre ${f.brand}. Use o contato informado no briefing.\n\nAdapte o tempo, as cenas e a fala antes de gravar.`}:{};}
