import {env} from "cloudflare:workers";
import {getChatGPTUser} from "../app/chatgpt-auth";
export const runtimeEnv = env as Cloudflare.Env;
export function database(){if(!runtimeEnv.DB)throw new Error("Banco indisponível.");return runtimeEnv.DB;}
export async function identity(request:Request){
 const user=await getChatGPTUser();if(!user)return null;
 if(request.method!=="GET"&&request.method!=="HEAD"){
  if(request.headers.get("sec-fetch-site")==="cross-site")return null;
  const origin=request.headers.get("origin");if(origin&&origin!==new URL(request.url).origin)return null;
 }
 return user.userId;
}
export function error(message:string,status=400){return Response.json({error:message},{status,headers:{"Cache-Control":"no-store"}});}
export function json(value:unknown,status=200){return Response.json(value,{status,headers:{"Cache-Control":"no-store"}});}
export async function body(request:Request){if(Number(request.headers.get("content-length")||0)>40000)throw new Error("Conteúdo muito grande.");const raw=await request.text();if(raw.length>40000)throw new Error("Conteúdo muito grande.");return JSON.parse(raw);}
