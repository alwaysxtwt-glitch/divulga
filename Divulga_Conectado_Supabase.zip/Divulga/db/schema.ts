import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";
export const campaigns = sqliteTable("campaigns", {
 id: text("id").primaryKey(), owner: text("owner").notNull(), title: text("title").notNull(),
 payload: text("payload").notNull(), status: text("status").notNull(), scheduledAt: text("scheduled_at"),
 createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(), version: integer("version").notNull().default(1),
}, t => [index("campaigns_owner_updated").on(t.owner,t.updatedAt)]);
export const assets = sqliteTable("assets", {
 id:text("id").primaryKey(),owner:text("owner").notNull(),filename:text("filename").notNull(),mime:text("mime").notNull(),size:integer("size").notNull(),createdAt:text("created_at").notNull()
});
export const events = sqliteTable("events", {
 id:text("id").primaryKey(),owner:text("owner").notNull(),campaignId:text("campaign_id").notNull(),title:text("title").notNull(),action:text("action").notNull(),createdAt:text("created_at").notNull()
}, t => [index("events_owner_created").on(t.owner,t.createdAt)]);
