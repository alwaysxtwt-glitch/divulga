# Comece por aqui — Divulga

Este ZIP contém o código-fonte do painel Divulga, incluindo Instagram, Facebook, LinkedIn e TikTok, na versão mais recente do repositório consultado. A IA gera legendas e, para TikTok, roteiros, quando há uma chave válida configurada no servidor.

## O que está no pacote

- `app/dashboard.tsx` e `app/globals.css`: interface e fluxo de campanhas.
- `app/api/generate/route.ts`: integração com a OpenAI Responses API.
- `app/api/campaigns/`: salvar e editar campanhas.
- `app/api/assets/`: upload privado de imagens e vídeos.
- `lib/contracts.ts`: validação dos dados e modelos de conteúdo.
- `lib/server.ts` e `app/chatgpt-auth.ts`: acesso ao ambiente e identificação do usuário.
- `db/schema.ts` e `drizzle/`: tabelas e migrações.
- `package.json`, `pnpm-lock.yaml`, `vite.config.ts` e `build/`: dependências e configuração do projeto.
- `README.md`: arquitetura e itens ainda necessários para publicação automática.

## Rodar localmente

1. Extraia o ZIP e abra a pasta `Divulga` no editor.
2. Use Node.js compatível com o campo `engines` do `package.json` (mínimo declarado: 22.13.0) e a versão de pnpm indicada em `packageManager`.
3. Instale as dependências: `pnpm install --frozen-lockfile`.
4. Gere a configuração de build: `pnpm build`.
5. Aplique a migração somente no banco local:

   `node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_soft_union_jack.sql`

6. Execute `pnpm dev` e abra o endereço local exibido no terminal.
7. No desenvolvimento local do perfil portátil, visite `/signin-with-chatgpt?return_to=/` no mesmo endereço para usar a identidade de teste. Essa identidade existe apenas para desenvolvimento; não autoriza acesso ao Site publicado.

Não aplique novamente uma migração já aplicada no banco local. Alterações futuras de schema devem gerar novas migrações. Dependências instaladas e dados de execução não foram incluídos; são criados no seu ambiente.

## Finalizar a geração por IA

A geração por IA desta versão usa a Edge Function `divulga-ai` no Supabase. A `OPENAI_API_KEY` fica armazenada somente nos Secrets do projeto Supabase e não deve ser colocada neste ZIP nem no frontend.

- O botão “Gerar com IA” consulta `/api/status`, que verifica a Edge Function `divulga-ai`.
- `/api/generate` envia o briefing para o Supabase, e a Edge Function chama a OpenAI usando o Secret `OPENAI_API_KEY`.
- A chave pública/anon do Supabase presente no backend do Site não concede acesso privilegiado ao banco; o segredo da OpenAI permanece somente no Supabase.
- Não coloque `OPENAI_API_KEY` no navegador nem no código-fonte.

O arquivo de exemplo é um modelo de configuração, não uma chave criada. Este pacote não verifica nem transfere créditos, chaves ou configurações que possam ter sido feitas em outra conversa.

## Hospedar em outro ambiente

Este projeto foi construído para **Cloudflare Workers + D1 + R2** e para a autenticação fornecida por Sites. O ZIP inclui o código completo dessa implementação.

Para continuar no mesmo Site, preserve a identidade em `.openai/hosting.json`. Para criar outro Site, o novo projeto deve receber uma identidade própria pelo fluxo de criação; não reutilize essa identidade para publicar uma cópia independente.

Para Replit ou outro servidor Node, é necessária adaptação: substituir os bindings de `cloudflare:workers` em `lib/server.ts` e `db/index.ts`, usar banco e armazenamento disponíveis no destino e implementar autenticação e autorização próprias. Os headers autenticados de Sites não podem ser simplesmente aceitos de clientes externos. Copiar a interface para outro provedor não configura automaticamente o backend.

## O que ainda falta para divulgação automática

As campanhas guardam datas como planejamento. **A publicação automática nas redes ainda não foi implementada.** Será necessário implementar OAuth, armazenar tokens com segurança, validar mídia e permissões por plataforma, criar fila de publicação com idempotência e tentativas controladas e registrar os IDs/URLs retornados pelas redes. A tela de conexões identifica esse estado como pendente.

Você pode entregar este ZIP a um desenvolvedor para completar a geração por IA e os publicadores. Nenhuma chave, token, banco de produção, arquivo enviado por usuário ou histórico de Git acompanha o pacote.
