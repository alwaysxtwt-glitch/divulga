# Divulga — MVP de planejamento multicanal

Painel privado em português para Instagram, Facebook, LinkedIn e TikTok. O projeto usa React/Vinext e um backend compatível com Cloudflare Workers. D1 guarda campanhas e histórico; R2 guarda imagens e vídeos. A publicação é privada por padrão.

## O que já funciona

- Briefing com marca, público, objetivo, tom e redes.
- Modelos editáveis derivados do briefing, identificados como modelos (não IA).
- Endpoint de geração real pela OpenAI Responses API, condicionado a segredo configurado.
- Edição independente por rede, cópia do texto e prévia ilustrativa.
- TikTok com legenda e roteiro de vídeo separados, prévia vertical e planejamento salvo. O roteiro fica no JSON da campanha; campanhas existentes continuam compatíveis.
- Upload de JPG, PNG, WebP e MP4 até 20 MB.
- Salvar, reabrir e atualizar rascunhos; aprovar conteúdo; guardar data planejada.
- Calendário no horário de Brasília e histórico de atividades.
- Autorização por usuário em todas as operações e arquivos. Atualizações usam versão para evitar sobrescritas concorrentes.

## Limitações atuais

OAuth e publicadores das redes ainda não estão implementados. A fila de jobs, retries, métricas, renovação e criptografia de tokens também não estão implementados. Datas geram o estado `awaiting_connection`, nunca uma publicação simulada ou uma promessa de agendamento ativo. Não há modo de publicação automática habilitado.

Geração por IA é desabilitada sem `OPENAI_API_KEY`. Configure esse segredo por meio das configurações seguras de Sites; não coloque a chave no navegador, repositório ou em mensagens. O modelo pode ser escolhido com `OPENAI_MODEL` (padrão `gpt-5`). A IA retorna versões por rede e exige revisão. A chave e o acesso ao serviço não foram configurados nesta entrega.

## Arquitetura

`Painel React → rotas autenticadas → D1/R2`

`Briefing → /api/generate → OpenAI Responses API → versões editáveis → aprovação`

Rotas:

| Rota | Uso |
|---|---|
| GET /api/campaigns | Campanhas e histórico do usuário |
| POST /api/campaigns | Criar campanha |
| PUT /api/campaigns/:id | Atualizar com checagem de versão |
| GET /api/status | Disponibilidade dos recursos |
| POST /api/generate | Geração de conteúdo quando ativada |
| POST /api/assets | Enviar mídia privada |
| GET /api/assets/:id | Ler mídia do próprio usuário |

O modelo de dados tem `campaigns`, `assets` e `events`. Campanhas guardam briefing e versões em JSON; campos consultados e ordenados ficam em colunas. Migrações Drizzle são versionadas em `drizzle/`.

## Evolução para publicação automática

1. Implementar OAuth oficial de Meta, LinkedIn e TikTok com callback autenticado, state de uso único, escopos mínimos e tokens criptografados no servidor. Obter aprovação e credenciais de cada aplicativo.
2. Guardar contas em `social_accounts` e criar `publication_jobs`, com um job por destino. A autorização de publicação precisa identificar conta e conteúdo final.
3. Implementar publicadores específicos por formato. Validar mídia, requisitos da conta e limites de cada plataforma antes de confirmar o agendamento.
4. Rodar uma fila ou rotina periódica com bloqueio atômico, idempotência, backoff, tentativas limitadas e reconciliação de resultados. Uma resposta incerta de publicação precisa de reconciliação antes de repetir.
5. Mudar o estado para publicado somente após confirmação e guardar o ID e URL retornados pela rede. Coletar métricas reais, sem dados fictícios.
6. Adicionar autorização explícita para campanhas totalmente automáticas depois que o fluxo aprovado estiver validado.

## Desenvolvimento e entrega

O starter conserva scripts e lockfile próprios. Use o perfil de execução e os helpers do plugin Sites para instalação, build e publicação. Para alterações de schema, gere novas migrações com Drizzle, revise SQL e preserve migrações já aplicadas. Segredos ficam no ambiente do Site. O acesso privado é aplicado pela plataforma; a aplicação também exige os headers de identidade autenticada nas rotas de dados.

Referência de geração: https://developers.openai.com/api/docs/guides/text

No TikTok, o publicador futuro deve usar a Content Posting API, obter consentimento e respeitar as opções retornadas pela conta. Publicação pública depende de auditoria do aplicativo; clientes não auditados ficam restritos a visualização privada. Referência: https://developers.tiktok.com/docs/en/content-posting-api-get-started
